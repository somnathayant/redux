import React from 'react';
import axios from 'axios';
import BootstrapTable from "react-bootstrap-table-next";
import { Redirect } from 'react-router-dom';
import { History } from 'react-router-dom'

export default class DisplayEmployeeComponent extends React.Component {

    constructor(props) {
        super(props);
        this.onSubmit = this.onSubmit.bind(this);
        
        this.state = {
              id:'',
            employee_name: '',
            employee_desiganation: '',
            employee_salary: '',
               employees:[],
               toUpdate:'',
               columns:[
                {
                  dataField:"id",
                  hidden: true
                },
                {
                  dataField:"employee_name",
                  text: "Employee Name"
                },
                {
                  dataField:"employee_desiganation",
                  text: "Employee Desiganation"
                },
                {
                  dataField:"employee_salary",
                  text: "Employee Salary"
                },
              ],    
              data1:[
                {
                  employee_salary: 3,
                  employee_name: "bagel",
                  employee_desiganation: "1.19",
                  id:90
                },
              ]    

        }
    
        axios.get("http://localhost:4000/emps").then(res=>
        {   
          this.setState({
            employees:res.data
          });
            
            
        }
        ).catch(function(error)
        {
            alert("No Employee Found");
        }
        );//end of method get

        this.setState({
          toUpdate:"NA"
      })

    }//end of constructor

    onChangeEmployeeId(e) {
      this.setState({
          id: e.target.value
      })
  }

    onSubmit(e) {
      
      sessionStorage.setItem("key",this.state.id);
      this.setState({
        toUpdate:"update"
      });
      //return <Redirect to={'/update'} />
      e.preventDefault();
    }
    render() 
    {
      
        return (
          <div>
          <form onSubmit={this.onSubmit}>
                    
                    
                    <div className="form-group">
                        <label>Employee Update:Please Enter Employee Id  </label>
                        <input
                            type="text"
                            className="form-control"
                            value={this.state.id}
                            onChange={this.onChangeEmployeeId}
                        />
                        <div id="error_name"></div>
           </div>
           <div className="form-group">
                        <input type="submit" value="Save" className="btn btn-primary" />
                    </div>
           </form>

            <BootstrapTable keyField="id" data={this.state.employees} columns={this.state.columns}/>
            

            </div>
           
        )}
}