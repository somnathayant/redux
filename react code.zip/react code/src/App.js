import React from 'react';
import './App.css';
import { Route, BrowserRouter as Router, Switch, Link,Redirect } from 'react-router-dom';
import CreateEmployee from './CreateEmployee';
import NotFoundComponent from './404Component';
import HomeComponent from './HomeComponent';
import UpdateEmployeeComponent from './UpdateEmployee.Component';
import DisplayEmployeeComponent from './DisplayEmployee.component'

function App() {
  return (
    <Router>
        <div className="container-fluid">

          <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
            <ul className="navbar-nav">
              <li className="nav-item">

              <Link to={'/home'} className="nav-link">Home</Link>
              
              </li>
              <li className="nav-item">
                <Link to={'/create'} className="nav-link">Create</Link>
                </li>
                <li className="nav-item">
                <Link to={'/display'} className="nav-link">Display Employee</Link>
                </li>
                <li className="nav-item">
                <Link to={'/update'} className="nav-link">Update Employee</Link>
              </li>
              
            </ul>
          </nav>

          <div className="App">
            <Switch>
              
              <Route  exact path="/" component={HomeComponent} />
              <Route  exact path="/home" component={HomeComponent} />
                <Route  exact path="/create" component={CreateEmployee} />
                <Route  exact path="/display" component={DisplayEmployeeComponent} />
                <Route  exact path="/update" component={UpdateEmployeeComponent} />
                <Route    component={NotFoundComponent} />
                
             
            </Switch>
          </div>
        </div>
      </Router>
  );
}

export default App;
