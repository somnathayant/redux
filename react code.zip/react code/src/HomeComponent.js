import React from 'react';
import axios from 'axios';
export default class HomeComponent extends React.Component {

    constructor(props) {
        super(props);

    }
//js 







    render() {
        return (
            <h1>home</h1>
        )}
}